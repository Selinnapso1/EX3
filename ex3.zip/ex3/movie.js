/* שמות המגישים :  
	 יליזבטה סמעאן 337968382 
	 318461811 סילין נפסו 
	 322664079 ריטה צ'רפק 
     07/04/2025
     Express.js, sqlite3, path, fs
     */
    
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const app = express();
app.set('view engine', 'ejs');
app.set('views', __dirname); // Set views directory to current directory

// Serve static files from current directory
app.use(express.static(__dirname));

// Database connection
const db = new sqlite3.Database('./db/rtfilms.db');

app.get('/', function(req, res) {
    const movieCode = req.query.title;
    console.log('Requested movie code:', movieCode);
    
    // Get movie details from FILMS table
    db.get(`
        SELECT * FROM FILMS 
        WHERE FilmCode = ?
    `, [movieCode], (err, movie) => {
        if (err) {
            console.error('Error fetching movie:', err);
            return res.status(500).send('Database error');
        }

        if (!movie) {
            console.log('Movie not found:', movieCode);
            return res.status(404).send('Movie not found');
        }

        console.log('Found movie:', movie.Title);

        // Get additional movie details from FilmDetails table
        db.all(`
            SELECT Attribute, Value FROM FilmDetails 
            WHERE FilmCode = ?
        `, [movieCode], (err, details) => {
            if (err) {
                console.error('Error fetching movie details:', err);
                return res.status(500).send('Database error');
            }

            console.log('Found movie details:', details.length);

            // Convert details array to object
            const movieDetails = {};
            details.forEach(detail => {
                movieDetails[detail.Attribute] = detail.Value;
            });

            // Get reviews for the movie
            db.all(`
                SELECT * FROM Reviews 
                WHERE FilmCode = ?
            `, [movieCode], (err, reviews) => {
                if (err) {
                    console.error('Error fetching reviews:', err);
                    return res.status(500).send('Database error');
                }

                console.log('Found reviews:', reviews.length);

                // Process reviews to ensure rating is properly formatted
                const processedReviews = reviews.map(review => {
                    // Split the review text by newlines and get the second line
                    const lines = review.ReviewText.split('\n');
                    const ratingLine = lines[1] || ''; // Get second line or empty string if not present
                    const isFresh = ratingLine.includes('FRESH');
                    
                    return {
                        rating: isFresh ? 'FRESH' : 'ROTTEN',
                        quote: review.ReviewText,
                        reviewer: review.ReviewerName,
                        publication: review.Affiliation
                    };
                });

                // Calculate overall rating from FILMS.Score
                const overallRating = movie.Score;
                console.log('Overall rating:', overallRating);

                // Check for poster image
                const posterPath = fs.existsSync(path.join(movieCode, 'poster.png')) ? path.join(movieCode, 'poster.png') : path.join(movieCode, 'poster.jpg');
                const posterExists = fs.existsSync(posterPath);
                console.log('Poster exists:', posterExists);
                
                // Process links if they exist
                let formattedLinks = [];
                if (movieDetails['Links']) {
                    console.log('Raw links:', movieDetails['Links']);
                    const links = movieDetails['Links'].split(', ');
                    links.forEach(link => {
                        const parts = link.split(': ');
                        if (parts.length === 2) {
                            const [text, url] = parts;
                            formattedLinks.push({ text, url });
                        }
                    });
                    console.log('Formatted links:', formattedLinks);
                }
                
                // Prepare movie data for template
                const movieData = {
                    title: movie.Title,
                    year: movie.Year,
                    starring: movieDetails['Starring'] || '',
                    director: movieDetails['Director'] || '',
                    rating: movieDetails['Rating'] || '',
                    releaseDate: movieDetails['Theatrical release'] || movieDetails['Theatrical Release'] || '',
                    synopsis: movieDetails['Movie synopsis'] || '',
                    mpaaRating: movieDetails['Mpaa rating'] || '',
                    studio: movieDetails['Release company'] || '',
                    genre: movieDetails['Genre'] || '',
                    runtime: movieDetails['Runtime'] || '',
                    boxOffice: movieDetails['Box office'] || '',
                    links: formattedLinks,
                    overallRating: overallRating,
                    reviews: processedReviews,
                    posterPath: posterExists ? posterPath : 'default.png'
                };

                console.log('Rendering template with movie data');
                res.render('movie', { movie: movieData });
            });
        });
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
}); 